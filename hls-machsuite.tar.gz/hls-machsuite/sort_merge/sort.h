#include <stdio.h>
#include <stdlib.h>
#include <math.h>


#define SIZE 2048
#define TYPE int32_t
#define TYPE_MAX INT32_MAX

void ms_mergesort(TYPE a[SIZE]);
